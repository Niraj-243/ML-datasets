% Minimize      Z = -5x1 -7x2
% subject to        − 2x1 + 3x2 ≤ 6,
%                   6x1 + x2 ≤ 30,
%                   x1, x2 ∈ Z+ ∪ {0}
%%
A = [-2 3;6 1;-1 0;0 -1];
b = [6 30 0 0];
f = [-5 -7];
int_vars = [1];
init_n = 2;

% A = [2 5;6 5;-1 0;0 -1];
% b = [16 30 0 0];
% f = [-1 -1];
% n_init = 2;

[x,z] = fun(f,A,b,init_n,int_vars)

function [x,z] = fun(f,A,b,init_n,int_vars)
    [x,z] = linprog(f,A,b);
    if isempty(z)
        return
    end
    target_var = 0;
    fra = 0;
    for i=1:init_n
        if sum(int_vars==i)==0
            continue;
        end
        if x(i)-floor(x(i))<0.001 || ceil(x(i))-x(i)<0.001
            continue;
        end
        if x(i)-floor(x(i))>fra
            fra = x(i)-floor(x(i));
            target_var = i;
        end
    end
    if target_var==0
        return
    end
    v = x(target_var);
    v1 = floor(v);
    v2 = ceil(v);

    cons1 = zeros(1,size(A,2));
    cons1(target_var)=1;
    [x1,z1] = fun(f,[A ;cons1],[b v1],init_n,int_vars);

    cons2 = cons1*(-1);
    [x2,z2] = fun(f,[A;cons2],[b -v2],init_n,int_vars);
    
    if isempty(z1)
        x = x2;
        z = z2;
        return
    end
    if isempty(z2)
        x = x1;
        z = z1;
        return
    end
   
    if z1<=z2 
        x = x1;
        z = z1;
    else
        x = x2;
        z = z2;
    end
end










