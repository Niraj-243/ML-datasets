Cost = [2 4 6 11;10 8 7 5;13 3 9 12;4 6 8 3];
supply = [50 70 30 50];
demand = [25 30 105 20];
[n,m] = size(Cost);
%% If unbalanced
dif = sum(supply)-sum(demand);
if dif > 0
    demand = [demand dif];
    Cost = [Cost zeros(n,1)];
elseif dif < 0
    supply = [supply -dif];
    Cost = [Cost ;zeros(1,m)];
end
%%
[n,m] = size(Cost);
Cost1 = Cost;
A = zeros(n,m);
while 1
    [least_col,ind_row] = min(Cost);
    [least,ind_col] = min(least_col);
    ind_row = ind_row(ind_col);
    if least == inf
        break
    end
    mi = min(supply(ind_row),demand(ind_col));
    supply(ind_row) = supply(ind_row) - mi;
    demand(ind_col) = demand(ind_col) - mi;
    A(ind_row,ind_col) = mi;
    Cost(ind_row,ind_col) = inf;
end
disp('Allotment is :')
disp(A)
disp('Total Cost = ')
disp(sum(sum(A.*Cost1)))