Cost = [2 4 6 11;10 8 7 5;13 3 9 12;4 6 8 3];
supply = [50 70 30 50];
demand = [25 30 105 20];
[n,m] = size(Cost);
%% If unbalanced
dif = sum(supply)-sum(demand);
if dif > 0
    demand = [demand dif];
    Cost = [Cost zeros(n,1)];
elseif dif < 0
    supply = [supply -dif];
    Cost = [Cost ;zeros(1,m)];
end

%%
[n,m] = size(Cost);
A = zeros(n,m);
Cost1 = Cost;
while 1
    A
    if sum(sum(Cost==inf))==n*m
        break
    end
    pen_row = zeros(1,n);
    pen_col = zeros(1,m);
    for i=1:n
        row_sort = sort(Cost(i,:));
        if ~isinf(row_sort(2)) 
            pen_row(i) = row_sort(2)-row_sort(1);
        elseif ~isinf(row_sort(1))
            pen_row(i) = row_sort(1);
        else
            pen_row(i) = row_sort(2)-row_sort(1);
        end

    end

    for j=1:m
        col_sort = sort(Cost(:,j));
        if ~isinf(col_sort(2))
            pen_col(j) = col_sort(2)-col_sort(1);
        elseif ~isinf(col_sort(1))
            pen_col(j) = col_sort(1);
        else
            pen_col(j) = col_sort(2)-col_sort(1);
        end

    end
    
    if max(pen_row) > max(pen_col)
        [~,row] = max(pen_row);
        [~,col] = min(Cost(row,:));
        allot = min(supply(row),demand(col));
        supply(row) = supply(row)-allot;
        demand(col) = demand(col)-allot;
        A(row,col) = allot;
        Cost(row,col) = inf;
    else
        [~,col] = max(pen_col);
        [~,row] = min(Cost(:,col));
        allot = min(supply(row),demand(col));
        supply(row) = supply(row)-allot;
        demand(col) = demand(col)-allot;
        A(row,col) = allot;
        Cost(row,col) = inf;
    end
end
disp('Final allocation is : ')
disp(A)
disp('Total cost is : ')
disp(sum(sum(A.*Cost1)))
