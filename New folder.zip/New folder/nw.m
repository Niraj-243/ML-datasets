Cost = [2 4 6 11;10 8 7 5;13 3 9 12;4 6 8 3];
supply = [50 70 30 50];
demand = [25 30 105 20];
[n,m] = size(Cost);

%% If unbalanced
dif = sum(supply)-sum(demand);
if dif > 0
    demand = [demand dif];
    Cost = [Cost zeros(n,1)];
else
    supply = [supply -dif];
    Cost = [Cost ;zeros(1,m)];
end
%%
Cost1 = Cost;
[n,m] = size(Cost);
row = 1;
col = 1;
A = zeros(n,m);
while row<=n && col<=m
    A
    mi = min(supply(row),demand(col));
    A(row,col) = mi;
    supply(row) = supply(row) - mi;
    demand(col) = demand(col) - mi;

    if supply(row) == 0
        row = row + 1;
    else
        col = col + 1;
    end
end
disp('Final allotment is :')
disp(A)
disp('Cost = ')
disp(sum(sum(A.*Cost1)))