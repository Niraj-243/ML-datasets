A = [5 3 2 8;
     7 9 2 6;
     6 4 5 7;
     5 7 7 8];
A = [13 8 16 18 19;9 15 24 9 12;12 9 4 4 4;6 12 10 8 13;15 17 18 12 20];
%%
clc
A1=A;
[n,m] = size(A); 
A = operation(A);
[crossed_row,crossed_col,allot] = cross(A);

while sum(crossed_col)+sum(crossed_row)<n
    A = change(A,crossed_row,crossed_col);
    A = operation(A);
    [crossed_row,crossed_col,allot] = cross(A);

end

for i=1:n
    for j=1:m
        if sum(allot(i,:))==0 && sum(allot(:,j))==0
            allot(i,j)=1;
        end
    end
end

allot
disp('Total Cost = ')
disp(sum(sum(allot.*A1)))


function [B] = change(A,crossed_row,crossed_col)
    B = A;
    [n,m] = size(B);
    mi = inf;
    for i=1:n
        if crossed_row(i)==1
            continue
        end
        for j=1:m
            if crossed_col(j)==1
                continue
            end
            if mi>B(i,j)
                mi = B(i,j);
            end
        end
    end

    for i=1:n
        for j=1:m
            if crossed_row(i)==1 && crossed_col(j)==1
                B(i,j) = B(i,j) + mi;
            elseif crossed_row(i)==0 && crossed_col(j)==0
                B(i,j) = B(i,j) - mi;
            end
        end
    end
end


function [crossed_row,crossed_col,allot] = cross(A)
    B = A;
    [n,m] = size(B);
    crossed_row = zeros(1,n);
    crossed_col = zeros(1,m);
    allot = zeros(n,m);
    for i=1:n
        [num,ind] = num_row_zero(B,crossed_col,i);
        if num==1
            allot(i,ind) = 1;
            crossed_row(i) = 1;
            crossed_col(ind) = 1;
        end
    end
    for j=1:m
        if crossed_col(j)==1
            continue
        end
        [num,ind] = num_col_zero(A,crossed_row,j);
        if num==1
            allot(ind,j) = 1;
            crossed_row(ind)=1;
            crossed_col(j)=1;
        end
    end
    crossed_row = zeros(1,n);
    crossed_col = zeros(1,m);
    for i=1:n
        if sum(allot(i,:))==0
            crossed_row(i)=1;
        end
    end
    do=1;
    while do
        do=0;
        for i=1:n
            if crossed_row(i)==0
                continue
            end
            for j=1:m
                if A(i,j)==0 && crossed_col(j)==0
                    do=1;
                    crossed_col(j)=1;
                    for k=1:n
                        if A(k,j)==0 && allot(k,j)==1
                            crossed_row(k)=1;
                        end
                    end
                end
            end
        end
    end

    crossed_row = 1-crossed_row;

end


function [num,ind] = num_col_zero(A,crossed_row,col)
    [n,~] = size(A);
    num=0;
    ind=0;
    for i=1:n
        if crossed_row(i)==1
            continue
        end
        if A(i,col)==0
            num = num+1;
            ind=i;
        end
    end

end

function [num,ind] = num_row_zero(A,crossed_col,row)
    [~,m] = size(A);
    num = 0;
    ind = 0;
    for j=1:m
        if crossed_col(j)==1
            continue;
        end
        if A(row,j) == 0
            ind = j;
            num = num+1;
        end
    end
end

function [B] = operation(A)
    B = A;
    [n,m] = size(A);
    for i=1:n
        B(i,:) = B(i,:) - min(B(i,:));
    end
    for j=1:m
        B(:,j) = B(:,j) - min(B(:,j));
    end
end